#include <iostream> //c++에선 .h 헤더 쓰지 않음

int main()
{
	std::cout<<"남아수공독오거서 아무말대잔치"<<std::endl;
	return 0;
}
